import React, { Component } from 'react';
import './ChatHistory.css';

import { HOC } from '../../HOC/HOC';
import scrollDownIcon from '../../_static_/images/icons/scrollDown.png';

class ChatHistory extends Component {
    state = {
        scrollTop : 0,
        canPullDown : false,
    }

    componentDidMount () {
        const chatHistory = document.getElementById('chat-list');

        chatHistory.addEventListener('scroll', () => {
            const scrollTop = chatHistory.scrollTop;
            if (scrollTop > this.state.scrollTop) {
                this.setState({ scrollTop : scrollTop, canPullDown : false });
            } else if ((this.state.scrollTop - scrollTop) > 100) {
                this.setState({ canPullDown : true });
            } else {
                this.setState({ canPullDown : false });
            }
        });
    }

    scrollToBottom = () => {
        const chatHistory = document.getElementById('chat-list');
        const scrollStep = (this.state.scrollTop - chatHistory.scrollTop) / 30;
        const scrollDown = setInterval(() => {
            chatHistory.scrollTop += scrollStep;
            if(chatHistory.scrollTop >= this.state.scrollTop)
                clearInterval(scrollDown);
        }, 1);
    }

    render() {
        let attachClass;
        const chatList = this.props.conversation.map((dialogue, index) => {
            attachClass = index % 2 ? "user" : "watson";
            return (
            <li key={index}
                className={attachClass}>
                {index % 2 ? dialogue.user : dialogue.watson}
            </li>
            )
        });
        
        const pullDownStyle = this.state.canPullDown ? { display: 'block' } : { display: 'none' };

        return (
            <HOC>
                <ul className="chat-history" id="chat-list">
                    <li className="watson">testing! aey wsup look whose back</li>
                    <li className="watson">Damn I have to do all this just for testing my scroll bar</li>
                    <li className="user">Yeah sad for you</li>
                    <li className="watson">Dude! thats you who is doing all this not me in reality</li>
                    <li className="user">whatt!!!! Oh damn I just forgot that you are a bot. not a real being... Man! I dont want to do this all day</li>
                    {chatList}
                </ul>
                <div className="scrollDownToCurrentDialogue"
                     style={pullDownStyle}
                     onClick={this.scrollToBottom}>
                    <img src={scrollDownIcon} alt="Go Down"/>
                </div>
            </HOC>
        );
    }
};

export default ChatHistory;