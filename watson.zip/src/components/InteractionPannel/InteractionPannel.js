import React from 'react';
import './InteractionPannel.css';

const interactionPannel = (props) => {
    return (
        <form className="chat-dialogue" onSubmit={props.chatHandle}>
            <div className="dialogue-space">
              <input id="dialogue-context" type="text" autoFocus
                     placeholder="type to chat..."/>
              <input id="dialogue-submit" type="submit" value=">" />
            </div>
        </form>
    );
};

export default interactionPannel;

