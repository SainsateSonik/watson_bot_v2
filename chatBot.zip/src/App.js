import React, { Component } from 'react';
import './App.css';
import AssistantV1 from 'watson-developer-cloud/assistant/v1';

import ChatHistory from './components/ChatHistory/ChatHistory';
import InteractionPannel from './components/InteractionPannel/InteractionPannel';

class App extends Component {
  state = {
    assistant : null,
    context : null,
    chat : [],
    inputString : "",
    updating : true
  }

  componentDidMount() {
    const assistant = new AssistantV1({
      version: '2018-09-20',
      username: '86ec7c48-234c-42ce-a250-8629ee63d642',
      password: 'YrQEl36UYhKD',
      url: 'https://gateway.watsonplatform.net/assistant/api'
    });
    this.setState( { assistant : assistant });
  }

  componentDidUpdate() {
    if(this.state.updating) {
      this.conversation(this.state.inputString, false);
    }
  }

  inputChangeHandler = (event) => {
    this.setState({ inputString : event.target.value });
  }

  conversation = (message, updateFlag) => {
    this.state.assistant.message({
        workspace_id: 'a4ee72b7-94f1-4828-9c17-b4bfc99814c3',
        input: {'text': message},
        context: this.state.context
      }, (err, response) => {
        if (err){
          alert("ERROR!!!!!");
          console.log('error:', err);
        }
        else {
          const chat = [...this.state.chat];
          chat.push({ watson : response.output.text[0] });
          this.setState({
            context : response.context,
            chat : chat,
            updating : updateFlag,
            inputString : ""
          });
        }
    });
  };

  chatHandle = (event) => {
    event.preventDefault();
    const chat = [...this.state.chat];
    chat.push({ user : document.getElementById('dialogue-context').value });
    this.setState({ chat : chat, updating : true });
  }

  render() {
    return (
      <div className="App">
        <div className="chat-space">
          <ChatHistory conversation={this.state.chat}/>
          <InteractionPannel inputString={this.state.inputString}
                             changeHandle={this.inputChangeHandler}
                             chatHandle={this.chatHandle}/>
        </div>
      </div>
    );
  }
}

export default App;
