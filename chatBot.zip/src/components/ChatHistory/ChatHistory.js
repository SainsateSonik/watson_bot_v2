import React from 'react';
import './ChatHistory.css';

const chatHistory = (props) => {
    let attachClass;
    const chatList = props.conversation.map((dialogue, index) => {
        attachClass = index % 2 ? "user" : "watson";
        return (
          <li key={index}
              className={attachClass}>
            {index % 2 ? dialogue.user : dialogue.watson}
          </li>
        )
    });
    
    return (
        <ul className="chat-history">
            {chatList}
        </ul>
    );
};

export default chatHistory;