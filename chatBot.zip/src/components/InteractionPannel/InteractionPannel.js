import React from 'react';
import './InteractionPannel.css';

const interactionPannel = (props) => {
    return (
        <form className="chat-dialogue" onSubmit={props.chatHandle}>
            <div className="dialogue-space">
              <input id="dialogue-context" type="text"
                     placeholder="type here to chat --"
                     value={props.inputString} 
                     onChange={props.changeHandle}/>
              <input id="dialogue-submit" type="submit" value=">" />
            </div>
        </form>
    );
};

export default interactionPannel;

